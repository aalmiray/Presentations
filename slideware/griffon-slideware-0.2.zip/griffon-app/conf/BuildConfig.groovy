griffon {
    compiler {
        println "FOOOOOO"
        dependencies = []
    }
}
println "BARRR"
compileDependencies  = []
