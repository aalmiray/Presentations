import net.miginfocom.swing.MigLayout

slide(id: "slide@count@", layout: new MigLayout("fill","[center]","[center]")) {
    label("Insert your text here")
}
