slide(id: 'slide@count@', title: 'slide@count@') {
    migLayout(layoutConstraints: 'fill',
              columnConstraints: '[center]',
              rowConstraints: '[center]')
    label("Insert your text here")
}
